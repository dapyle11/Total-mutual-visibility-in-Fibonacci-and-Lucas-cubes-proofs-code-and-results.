#!/usr/bin/env python3
"""Exact polynomial and coefficient checks using only the Python standard library.

This supplement helper checks the rational free-dimension generating function,
its specialization from the component inventory, and the stated kappa identity.
It replaces the optional computer-algebra dependency of the research prototype.
"""
from collections import Counter
import argparse
import json
from component_inventory import inventories, order


def add(*polys):
    out = Counter()
    for p in polys:
        out.update(p)
    return {k: v for k, v in out.items() if v}


def scale(p, c):
    return {k: c * v for k, v in p.items() if c * v}


def mul(a, b):
    out = Counter()
    for (i, j), u in a.items():
        for (k, ell), v in b.items():
            out[i + k, j + ell] += u * v
    return {k: v for k, v in out.items() if v}


def monomial(z=0, t=0, coefficient=1):
    return {(z, t): coefficient}


NUMERATOR = {(0, 0): 1, (1, 1): 2, (2, 0): 2, (2, 1): -1,
             (3, 2): 1, (4, 0): 1, (4, 2): -1, (6, 1): 1, (6, 2): -1}
DENOMINATOR = {(0, 0): 1, (2, 1): -1, (3, 0): -1, (4, 2): -1,
               (5, 1): 1, (5, 0): -1, (7, 2): 1, (7, 1): -1}


def symbolic_checks():
    one = monomial()
    z = monomial(1)
    z2 = monomial(2)
    z3 = monomial(3)
    z4 = monomial(4)
    q = add(one, monomial(2, 1, -1), monomial(4, 2, -1))
    a = add(one, monomial(2, 1))  # Y = a/q.
    i = add(q, mul(z2, a))        # I = i/q.
    j = add(mul(z, q), mul(add(one, z3), a))  # J = j/q.
    h = add(q, scale(mul(z3, i), -1))
    # (a-q)/z is a polynomial, so no Laurent-polynomial machinery is needed.
    a_minus_q_over_z = {(u - 1, v): c for (u, v), c in add(a, scale(q, -1)).items()}
    e = add(q, a_minus_q_over_z, scale(mul(z2, a), 2), mul(z3, i))
    lhs_numerator = add(mul(e, h), mul(z4, mul(j, j)))
    assert mul(lhs_numerator, DENOMINATOR) == mul(NUMERATOR, mul(q, h))

    # Verify D_t(a,1)*L - a^2*D_z(a,1) modulo a^3+a-1.
    dt = Counter()
    dz = Counter()
    for (u, v), c in DENOMINATOR.items():
        if v:
            dt[u, 0] += v * c
        if u:
            dz[u - 1, 0] += u * c
    ell = {(2, 0): 2, (3, 0): 3, (4, 0): 4}
    residual = add(mul(dt, ell), scale(mul(z2, dz), -1))
    p = Counter({u: c for (u, _), c in residual.items()})
    for degree in range(max(p, default=0), 2, -1):
        c = p[degree]
        # a^degree = a^(degree-3) - a^(degree-2).
        p[degree] = 0
        p[degree - 3] += c
        p[degree - 2] -= c
    assert not any(p.values())


def coefficient_histograms(max_n):
    by_z = {}
    for (z, t), c in DENOMINATOR.items():
        by_z.setdefault(z, {})[t] = c
    answer = []
    for n in range(max_n + 1):
        p = Counter({t: c for (z, t), c in NUMERATOR.items() if z == n})
        for dz, polynomial in by_z.items():
            if dz == 0 or dz > n:
                continue
            for t, c in polynomial.items():
                for old_t, old_c in answer[n - dz].items():
                    p[t + old_t] -= c * old_c
        p = {t: c for t, c in p.items() if c}
        assert all(c > 0 for c in p.values())
        answer.append(p)
    return answer


def validate(max_n=60):
    symbolic_checks()
    expected = coefficient_histograms(max_n)
    actual = []
    for n, inventory in enumerate(inventories(max_n)):
        histogram = Counter()
        for factors, multiplicity in inventory.items():
            histogram[sum(factors)] += multiplicity * order(factors)
        assert dict(histogram) == expected[n], (n, histogram, expected[n])
        actual.append(dict(histogram))
    return {
        'max_n': max_n,
        'rational_free_dimension_generating_function_matches_type_inventory': True,
        'weighted_dimension_histograms': actual,
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--max-n', type=int, default=60)
    args = parser.parse_args()
    if args.max_n < 0:
        parser.error('--max-n must be nonnegative')
    print(json.dumps(validate(args.max_n), indent=2))
