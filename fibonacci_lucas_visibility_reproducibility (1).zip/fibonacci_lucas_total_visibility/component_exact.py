"""Exact total visibility by component types, without the A_n word graph.

Reuses the exact_total_visibility MIS kernel: an independent input/reduction,
not an independently implemented optimizer. Compare the component-type formula
against the earlier direct eligible-word enumeration and its saved results.
"""
from component_inventory import inventories
from exact_total_visibility import alpha_exact
from itertools import combinations
import json, time, argparse
from pathlib import Path


def product_words(rs):
    V=[0];offset=0
    for r in rs:
        W=[v for v in range(1<<r) if not(v & (v>>1))]
        V=[v|(w<<offset) for v in V for w in W];offset+=r
    return V


def open_packing(rs):
    V=product_words(rs);loc={v:i for i,v in enumerate(V)}
    pairs=[(1<<i)|(1<<j) for i,j in combinations(range(sum(rs)),2)]
    adj=[]
    for v in V:
        adj.append(sum(1<<loc[v^p] for p in pairs if v^p in loc))
    witness,calls,_=alpha_exact(adj)
    chosen=[v for i,v in enumerate(V) if witness>>i&1]
    assert all((a^b).bit_count()!=2 for a,b in combinations(chosen,2))
    return dict(type=list(rs),order=len(V),open_packing=len(chosen),
                recursion_states=calls,witness=chosen)


def run(N):
    F=inventories(N);types=sorted(set().union(*(C.keys() for C in F)),key=lambda rs:(sum(rs),rs))
    solved={}
    for rs in types:
        t=time.monotonic();solved[rs]=open_packing(rs)
        solved[rs]['seconds']=round(time.monotonic()-t,6)
    values=[sum(mult*solved[rs]['open_packing'] for rs,mult in C.items()) for C in F]
    with Path(__file__).with_name('exact_summary.json').open(encoding='utf-8') as source:
        old=json.load(source)
    for row in old:
        if row['dimension']<=N:assert row['mu_total']==values[row['dimension']],row
    return dict(values=values,types=[solved[rs] for rs in types],
                matches_direct_eligible_graph_through=min(N,max(row['dimension'] for row in old)))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--max-n',type=int,default=20)
    print(json.dumps(run(p.parse_args().max_n),indent=2))
