"""Audit component keys, product sizes, and counts of varying coordinates.

This finite check does not certify every edge of a product isomorphism.
"""
from independent_definition_audit import words,eligible,adjacency,components
from collections import Counter

def barriers(w):return tuple(i+1 for i in range(len(w)-3) if w[i:i+4]=='1001')
def key(w):
 B=barriers(w)
 if B:return ('B',)+B
 return ('p',next(i%2 for i,c in enumerate(w,1) if c=='1'))
def f(b):return (b-1)//2 if b%2 else max(0,(b-4)//2)
def factors(n,k):
 if k[0]=='p':
  if n%2==0:return ((n-2)//2,)
  return ((n+1)//2 if k[1]==1 else max(0,(n-5)//2),)
 B=k[1:]
 return (f(B[0]),)+tuple(max(0,(b-a-5)//2) for a,b in zip(B,B[1:]))+(f(n-B[-1]-2),)
def fibsize(m):
 a,b=1,2
 for i in range(m):a,b=b,a+b
 return a

def audit(n):
 A=[w for w in words(n) if eligible(w)]
 K=adjacency(A); Cs=components(K);keys=set(); inventory=Counter()
 for C in Cs:
  ks={key(w) for w in C}; assert len(ks)==1
  k=next(iter(ks));assert k not in keys;keys.add(k)
  F=factors(n,k)
  prod=1
  for m in F:prod*=fibsize(m)
  assert prod==len(C),(n,k,F,len(C),prod)
  # Number of varying original coordinates must match free dimensions.
  assert sum(F)==sum(len({w[i] for w in C})==2 for i in range(n)),(n,k,F)
  inventory[tuple(sorted(m for m in F if m>0))]+=1
 print(n,len(A),len(Cs),dict(sorted(inventory.items())),flush=True)

if __name__=='__main__':
 import sys
 for n in range(2,int(sys.argv[1])+1):audit(n)
