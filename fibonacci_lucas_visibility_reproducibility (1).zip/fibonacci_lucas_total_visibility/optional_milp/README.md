# Optional numerical MILP cross-check

This optional directory is not imported or run by the standard-library core
verification driver. It requires NumPy and SciPy with `scipy.optimize.milp` and
the included HiGHS backend. The relocated script was tested with Python 3.12.14,
NumPy 2.3.5, and SciPy 1.17.0. No third-party dependency is bundled.

From the parent `repro` directory, with those dependencies already available:

```sh
mkdir -p test_outputs/optional_milp
python3 -B optional_milp/independent_milp_audit.py --min-n 1 --max-n 20 > test_outputs/optional_milp/independent_milp_all20.jsonl
```

To repeat only the later extension, use `--min-n 16 --max-n 20`. Do not disable
assertions. Reference data are resolved relative to the script, not the working
directory. The optimization time limit is 30 seconds per dimension, excluding
model construction. Runtime and memory increase with dimension. A nonoptimal
status, nonzero gap, or disagreement with the exact-recursion value causes a
nonzero exit after its diagnostic record is printed.

The model derives forbidden vertices and conflicting pairs directly from
common neighborhoods in the Fibonacci cube. It does not use the core
eligible-word formula, component inventory, or exact MIS optimizer. Each
returned set is checked against these local constraints using integer
arithmetic. This is not a global-definition BFS test of every subset.

Preserved records:

- `independent_milp_16_20.jsonl`: the n=16,...,20 extension, with witness sizes
  201, 303, 405, 549, and 812.
- `independent_milp_all20.jsonl`: the complete n=1,...,20 cross-check, also
  covering the range of the earlier preliminary experiment.

Every supplied row reports status 0 (HiGHS Optimal), zero relative gap,
matching primal and dual numerical objective values, integer-valid witnesses,
and agreement with the exact-recursion result. The optimization minimizes
negative cardinality, so objective and dual-bound signs are negative. Solver
versions can select different optimal witnesses or explore different numbers
of nodes; those differences alone are not failures.

HiGHS status, bounds, and gaps are floating-point numerical solver reports,
not independently checkable exact-rational or formal proof certificates.
Integer witness validation certifies feasibility, not optimality by itself.
The separate exact-recursion computation is part of the standard-library core.
The global-definition all-eligible-subsets BFS range remains n<=7.

The author/contribution and licensing notice in `../LICENSE-NOTICE.txt` applies.
In particular, the research data have the stated CC BY 4.0 designation; a
separate software license remains pending author choice.
