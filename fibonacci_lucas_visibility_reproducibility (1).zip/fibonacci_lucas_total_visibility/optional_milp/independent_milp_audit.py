"""Independent direct-common-neighbor MILP check, dimensions 1 through 20.

HiGHS status/dual bound/gap are numerical solver reports, not exact
rational proof certificates. Each returned witness is checked in integer arithmetic
against the directly constructed local visibility constraints.
"""
from itertools import combinations
from time import monotonic
import json
from pathlib import Path
import numpy as np
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import coo_matrix


def graph(n):
    V=[v for v in range(1<<n) if not(v&(v>>1))];S=set(V)
    neighbors={v:{v^(1<<j) for j in range(n)}&S for v in V}
    singleton=set();pairs=set();masks=[(1<<i)|(1<<j) for i,j in combinations(range(n),2)]
    for a in V:
        for mask in masks:
            b=a^mask
            if b<=a or b not in S:continue
            C=neighbors[a]&neighbors[b]
            assert 1<=len(C)<=2
            if len(C)==1:singleton.update(C)
            else:pairs.add(tuple(sorted(C)))
    eligible=sorted(S-singleton)
    conflicts=[(a,b) for a,b in pairs if a not in singleton and b not in singleton]
    return V,eligible,singleton,pairs,conflicts


def solve(n):
    start=monotonic();V,E,forced,pairs,edges=graph(n);loc={v:i for i,v in enumerate(E)}
    rows=[];cols=[]
    for i,(a,b) in enumerate(edges):rows.extend([i,i]);cols.extend([loc[a],loc[b]])
    A=coo_matrix((np.ones(len(rows)),(rows,cols)),shape=(len(edges),len(E))).tocsc()
    r=milp(-np.ones(len(E)),integrality=np.ones(len(E)),bounds=Bounds(0,1),
           constraints=LinearConstraint(A,-np.inf,1),options={'time_limit':30,'mip_rel_gap':0})
    chosen=set() if r.x is None else {v for i,v in enumerate(E) if r.x[i]>.5}
    assert not(chosen&forced)
    assert all(not(a in chosen and b in chosen) for a,b in pairs)
    return dict(n=n,vertices=len(V),eligible=len(E),edges=len(edges),
                status=int(r.status),message=str(r.message),optimum=len(chosen),
                objective=None if r.fun is None else float(r.fun),
                dual_bound=None if not hasattr(r,'mip_dual_bound') else float(r.mip_dual_bound),
                mip_gap=None if not hasattr(r,'mip_gap') else float(r.mip_gap),
                node_count=None if not hasattr(r,'mip_node_count') else int(r.mip_node_count),
                integer_witness_valid=True,seconds=round(monotonic()-start,6),
                witness=[format(v,f'0{n}b') for v in sorted(chosen)])

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--min-n',type=int,default=1);p.add_argument('--max-n',type=int,default=20)
    args=p.parse_args()
    if not 1 <= args.min_n <= args.max_n <= 20:
        p.error('Require 1 <= --min-n <= --max-n <= 20 for comparison with the supplied reference.')
    with (Path(__file__).resolve().parents[1] / 'exact_summary.json').open(encoding='utf-8') as source:
        expected={r['dimension']:r['mu_total'] for r in json.load(source)}
    for n in range(args.min_n,args.max_n+1):
        r=solve(n);r['matches_exact_recursion']=r['optimum']==expected[n]
        print(json.dumps(r),flush=True)
        if r['status'] != 0 or r['mip_gap'] != 0.0 or not r['matches_exact_recursion']:
            raise RuntimeError('Numerical optimality or agreement was not established; inspect the output record.')
