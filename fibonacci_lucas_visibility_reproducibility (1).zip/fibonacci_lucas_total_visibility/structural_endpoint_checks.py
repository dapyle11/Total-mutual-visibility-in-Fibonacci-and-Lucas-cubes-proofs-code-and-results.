#!/usr/bin/env python3
"""Reproducible checks for refined constants, cube fibres, and Lucas corollary.
All external state is untouched; output is JSON. Standard library only.
"""
from collections import defaultdict,deque
from itertools import combinations
from math import prod
import json,sys
from exact_total_visibility import alpha_exact,components

def eligible_path_words(n):
 def rec(i,w,last,z):
  if i==n:
   if z<=2:yield w
   return
  if z<3:yield from rec(i+1,w,0,z+1)
  if not last:yield from rec(i+1,w|(1<<i),1,0)
 yield from rec(0,0,0,1)

def addable_path(w,n):return ((1<<n)-1)&~(w|(w<<1)|(w>>1))
def eligible_path(w,n):
 u=addable_path(w,n)
 return not(w&(w>>1)) and not(u&(u>>1))
def removable_path(w,n):
 return 0 if not n else w&((w<<2)|1)&((w>>2)|(1<<(n-1)))
def path_statistics(n):
 sd=sm=sd2=sm2=count=0;errors_d=set();errors_m=set()
 for w in eligible_path_words(n):
  u=addable_path(w,n);M=w|u
  d=u.bit_count()+removable_path(w,n).bit_count();m=removable_path(M,n).bit_count()
  if n<=12:
   assert d==sum(eligible_path(w^(1<<i),n) for i in range(n))
  ones=[i for i in range(n) if w>>i&1];gaps=[b-a for a,b in zip(ones,ones[1:])]
  dg=gaps.count(4)+sum(a==b==2 for a,b in zip(gaps,gaps[1:]))
  mg=gaps.count(4)+sum(a in (2,4) and b in (2,4) for a,b in zip(gaps,gaps[1:]))
  errors_d.add(d-dg);errors_m.add(m-mg)
  assert 0<=d-dg<=4 and 0<=m-mg<=4
  count+=1;sd+=d;sm+=m;sd2+=d*d;sm2+=m*m
 return dict(n=n,eligible=count,degree_mean=sd/count,dimension_mean=sm/count,
  degree_mean_per_n=sd/count/n,dimension_mean_per_n=sm/count/n,
  degree_variance=sd2/count-(sd/count)**2,dimension_variance=sm2/count-(sm/count)**2,
  degree_boundary_errors=sorted(errors_d),dimension_boundary_errors=sorted(errors_m))

def cube_fibre(k):
 n=7*k-6;R=sum(1<<(7*j) for j in range(k));M=R
 for j in range(k-1):M|=(1<<(7*j+2))|(1<<(7*j+5))
 assert not addable_path(M,n)
 assert removable_path(M,n)==R
 vertices=[]
 for t in range(1<<k):
  w=M
  for j in range(k):
   if t>>j&1:w^=1<<(7*j)
  assert eligible_path(w,n) and w|addable_path(w,n)==M
  vertices.append(w)
 for a,b in combinations(range(1<<k),2):
  assert (vertices[a]^vertices[b]).bit_count()==(a^b).bit_count()
 return dict(k=k,n=n,fibre_order=1<<k,maximal_support=[i+1 for i in range(n) if M>>i&1],free_positions=[1+7*j for j in range(k)])

def cycle_independent(w,n):return not(w&(w>>1)) and not((w&1) and (w>>(n-1)&1))
def addable_cycle(w,n):
 mask=(1<<n)-1;left=((w<<1)&mask)|(w>>(n-1));right=(w>>1)|((w&1)<<(n-1))
 return mask&~(w|left|right)
def distances(G):
 out={}
 for a in G:
  D={a:0};q=deque([a])
  while q:
   v=q.popleft()
   for u in G[v]:
    if u not in D:D[u]=D[v]+1;q.append(u)
  out[a]=D
 return out

def total_visible(X,G,Ds):
 for a in G:
  D={a:0};q=deque([a])
  while q:
   v=q.popleft()
   if v!=a and v in X:continue
   for u in G[v]:
    if u not in D:D[u]=D[v]+1;q.append(u)
  if D!=Ds[a]:return False
 return True

def lucas_check(n):
 V=[w for w in range(1<<n) if cycle_independent(w,n)];VS=set(V)
 G={w:{w^(1<<i) for i in range(n)}&VS for w in V}
 A={w for w in V if cycle_independent(addable_cycle(w,n),n)}
 forced=set();E=set()
 for a in V:
  for i,j in combinations(range(n),2):
   b=a^(1<<i)^(1<<j)
   if b<=a or b not in VS:continue
   common=G[a]&G[b];assert 1<=len(common)<=2
   if len(common)==1:forced|=common
   else:E.add(tuple(sorted(common)))
 assert A==VS-forced
 E={e for e in E if all(w in A for w in e)}
 predicted=set()
 for a,b in combinations(sorted(A),2):
  xor=a^b
  if xor.bit_count()!=2:continue
  i,j=[k for k in range(n) if xor>>k&1]
  if j-i not in(1,n-1):predicted.add((a,b))
 assert E==predicted
 fibres=defaultdict(set)
 for w in A:fibres[w|addable_cycle(w,n)].add(w)
 fibretypes=defaultdict(int)
 for M,C in fibres.items():
  R=set(i for i in range(n) if M>>i&1)
  constraints=[]
  for v in range(n):
   if M>>v&1:continue
   Ns={u for u in((v-1)%n,(v+1)%n) if M>>u&1}
   assert Ns
   if len(Ns)==1:R-=Ns
   else:constraints.append(Ns)
  RF=sorted(R)
  Q={v:set() for v in R}
  for pair in constraints:
   if pair<=R:
    a,b=pair;Q[a].add(b);Q[b].add(a)
  Tsets=[]
  for mask in range(1<<len(RF)):
   T={v for j,v in enumerate(RF) if mask>>j&1}
   if all(not(Q[v]&T) for v in T):Tsets.append(T)
  assert {M^sum(1<<i for i in T) for T in Tsets}==C
  seen=set();types=[]
  for v in Q:
   if v in seen:continue
   reached={v};q=[v];seen.add(v)
   while q:
    a=q.pop()
    for b in Q[a]-seen:seen.add(b);reached.add(b);q.append(b)
   types.append(('cycle' if all(len(Q[a])==2 for a in reached) else 'path',len(reached)))
  fibretypes[str(sorted(types))]+=1
 W=sorted(A);where={w:i for i,w in enumerate(W)};adj=[0]*len(W)
 for a,b in E:
  i,j=where[a],where[b];adj[i]|=1<<j;adj[j]|=1<<i
 chosen,calls,_=alpha_exact(adj)
 if n<=7:
  Ds=distances(G)
  for mask in range(1<<len(W)):
   X={w for i,w in enumerate(W) if mask>>i&1}
   candidate=all(not(adj[i]&mask) for i in range(len(W)) if mask>>i&1)
   assert candidate==total_visible(X,G,Ds)
 return dict(n=n,graph_order=len(V),eligible=len(A),mu_total=chosen.bit_count(),conflict_edges=len(E),eligible_components=len(fibres),fibre_types=dict(fibretypes),direct_subsets_checked=(1<<len(W)) if n<=7 else 0)

def main():
 mode=sys.argv[1] if len(sys.argv)>1 else 'all'
 if mode in ('stats','all'):
  for n in range(1,29):print(json.dumps(dict(kind='path_statistics',**path_statistics(n))),flush=True)
 if mode in ('cubes','all'):
  for k in range(1,10):print(json.dumps(dict(kind='cube_fibre',**cube_fibre(k))),flush=True)
 if mode in ('lucas','all'):
  for n in range(3,17):print(json.dumps(dict(kind='lucas',**lucas_check(n))),flush=True)
if __name__=='__main__':main()
