# Fibonacci/Lucas total-visibility reproducibility supplement

Author: Daniel A. Pyle, Independent Researcher, ORCID 0009-0005-6456-1370.
AI-assisted mathematical and technical work: Lyra, powered by OpenAI. The
computational audits here are programmatic checks, not human peer review.

The core directory contains standard-library Python programs and finite reference
records for the accompanying manuscript. An optional SciPy-dependent numerical
MILP cross-check is isolated in `optional_milp/`. It contains no third-party papers.
See `LICENSE-NOTICE.txt` for the separate treatment of prose/data and software.

## Requirements and safe execution

Python 3.10 or later is required because the code uses `int.bit_count()`.
The supplement was tested with CPython 3.12.14. No package installation,
network access, external solver, or account is needed for the core. The optional
MILP directory has separate NumPy/SciPy requirements. Keep all files together;
script imports and reference-data reads are relative to this directory.

Run without `-O`, `-OO`, or `PYTHONOPTIMIZE`: assertions perform the checks.
Commands below assume the current directory is this `repro` directory. On
systems where the executable is named `python`, substitute it for `python3`.

Quick smoke test:

```sh
python3 -B verify_reproduction.py --output-dir test_outputs/quick
```

Reproduce every finite range represented by the supplied core reference records:

```sh
python3 -B verify_reproduction.py --full --output-dir test_outputs/full
```

The driver writes fresh results only in the chosen output directory. It compares
them with the supplied records, ignores elapsed-time fields, and uses a
1e-12 relative/absolute tolerance only for floating-point statistics. Integer
values and witnesses are compared exactly. Successful completion creates
`verification_report.json`; a nonzero exit status means a check did not finish
successfully. Each subprocess has a default 600-second timeout, adjustable with
`--timeout SECONDS`. A timeout is not a mathematical counterexample.

The quick test covers only the smaller ranges selected in the driver; it does
not rerun the Lucas or degree-statistics checks. Full mode is the recorded-range
verification. Exact independent-set recursion and all-subsets enumeration can
require exponentially growing time and memory. Increasing dimensions beyond
those documented here is not recommended without resource controls. Timings in
the reference JSON are historical observations, not complexity guarantees.

## Individual commands

These commands regenerate each principal output without overwriting references:

```sh
mkdir -p test_outputs/manual
python3 -B exact_total_visibility.py 20 > test_outputs/manual/exact_results.jsonl
python3 -B independent_definition_audit.py 7 > test_outputs/manual/definition_audit.txt
python3 -B independent_component_audit.py 17 > test_outputs/manual/component_audit.txt
python3 -B component_inventory.py --max-n 60 --direct-through 18 > test_outputs/manual/component_inventory_validation.json
python3 -B component_exact.py --max-n 20 > test_outputs/manual/component_exact_validation.json
python3 -B generating_function_checks.py --max-n 60 > test_outputs/manual/component_generating_function_validation.json
python3 -B structural_endpoint_checks.py all > test_outputs/manual/structural_endpoint_validation.jsonl
```

`structural_endpoint_checks.py` also accepts `stats`, `cubes`, or `lucas` to run
only that part. The full driver produces `exact_summary.json` from the exact
records by omitting witnesses. `independent_audit_validation.json` is the saved
summary of the two independent-audit programs; the driver checks their numerical
results against it rather than regenerating its descriptive metadata.

## Verification scope and limitations

- `exact_total_visibility.py`: exact independent-set optimization of the
  constructed Fibonacci conflict graph through n=20, with witnesses. The local
  common-neighbor construction is checked separately through n=12. This is not
  a direct BFS test of every candidate subset through n=20.
- `independent_definition_audit.py`: constructs Fibonacci graphs and tests the
  original global path definition by BFS for every subset of eligible vertices
  only through n=7. Singleton tests exclude all other vertices; pair tests check
  the proposed conflicts. There is no direct enumeration of every raw subset
  of all graph vertices. The script has a separately implemented independent-set
  recurrence, but that does not extend the global-subset BFS range.
- `independent_component_audit.py`: through n=17, checks that barrier keys
  classify eligible-graph components, product orders equal component sizes,
  and total factor dimensions equal the number of varying coordinates. These
  tests alone do not certify all edges of a product-graph isomorphism.
- `component_inventory.py`: checks the component-type generating series against
  direct maximal-independent-set enumeration through n=18 and its two scalar
  evaluations through n=60.
- `component_exact.py`: independently constructs product-type conflict graphs
  and reproduces values through n=20. It reuses `alpha_exact` from
  `exact_total_visibility.py`; it is an independent input/reduction check, not
  an independently implemented optimization algorithm.
- `generating_function_checks.py`: verifies the rational specialization and
  kappa polynomial identity by exact integer polynomial arithmetic, and compares
  full weighted free-dimension histograms through n=60. This new helper removes
  the optional computer-algebra dependency of the research prototype.
- `structural_endpoint_checks.py`: checks every eligible Fibonacci word's
  degree/free-dimension gap statistics through n=28, including direct one-bit
  degree checks through n=12; explicit cube-fibre constructions for k=1,...,9;
  and Lucas eligibility, conflicts, fibre constraints, and exact conflict-graph
  optimization for n=3,...,16. For Lucas cubes, global-definition BFS on all
  eligible subsets is restricted to n=3,...,7. The cycle convention is n>=3.

In `exact_results.jsonl` and `exact_summary.json`, `components` counts components
of the conflict graph. In the inventory/component audit, components are fibres
of the eligible induced graph. These are different graphs, so their component
counts and largest-component orders need not agree. The n=0 value appears in
the type computation under the one-vertex empty-word convention, not in the
positive-dimensional direct graph record.

Finite checks support, but do not replace, the manuscript's mathematical
arguments. The supplement contains no formal proof-assistant, SAT, or other
independently checkable optimality proof certificate. Witnesses certify feasible
sets; optimality relies on the exact recurrence and its implementation. The optional numerical MILP cross-check is not part of the dependency-free core
run; see `optional_milp/README.md`. No novelty,
peer-review, or all-dimension optimality formula is certified by these programs.

## Contents and provenance

The seven core reference files are `exact_summary.json`, `exact_results.jsonl`,
`independent_audit_validation.json`, `component_inventory_validation.json`,
`component_exact_validation.json`,
`component_generating_function_validation.json`, and
`structural_endpoint_validation.jsonl`. They are preserved from the research
computations, including historical timing fields.

The six original research programs retain their algorithms. The documentation clarifies independence and verification scope;
`component_exact.py` uses a robust relative reference-file read.
`generating_function_checks.py` and `verify_reproduction.py` are supplement
helpers. No temporary test output is needed to run the supplement.

## Optional independent MILP cross-check

`optional_milp/` contains `independent_milp_audit.py` and the preserved
`independent_milp_16_20.jsonl` and `independent_milp_all20.jsonl` records. Its
model is constructed from direct common-neighbor constraints rather than the
eligible-word formula or component-type inventory, and optimization uses
SciPy/HiGHS rather than the core MIS recurrence. All recorded n=1,...,20 runs
report optimal status, zero relative gap, and matching primal/dual objectives;
the selected sets are checked against the local constraints in integer
arithmetic. These numerical solver reports are not formal rational optimality
certificates and do not extend global-definition all-subsets BFS beyond n=7.
The complete record supersedes the need to bundle the older preliminary probe.

## Manuscript files

The full archive also contains `main.tex` and
`fibonacci_lucas_total_visibility.pdf`. The source has an inline bibliography
and needs no external figure files. With a standard LaTeX distribution, compile
it twice:

```sh
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

For a source-only manuscript upload, use the separately supplied Hexagon source
ZIP. That minimal archive contains only `main.tex`; this full reproducibility
archive is a separate computational supplement.
