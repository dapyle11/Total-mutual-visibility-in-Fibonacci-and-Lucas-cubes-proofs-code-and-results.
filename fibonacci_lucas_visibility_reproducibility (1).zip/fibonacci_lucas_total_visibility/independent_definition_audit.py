"""Independent audit of Fibonacci-cube total-visibility reductions."""
from itertools import product, combinations
from collections import deque,Counter
from functools import lru_cache

def words(n):
 return [''.join(t) for t in product('01', repeat=n) if all(t[i:i+2]!=('1','1') for i in range(n-1))]
def hamming(a,b):return sum(x!=y for x,y in zip(a,b))
def adjacency(W):return {a:{b for b in W if hamming(a,b)==1} for a in W}
def eligible(a):return '0000' not in '0'+a+'0'
def conflict(a,b):
 D=[i for i,(x,y) in enumerate(zip(a,b)) if x!=y]
 return len(D)==2 and D[1]-D[0]>1

def distances(G):
 out={}
 for a in G:
  dist={a:0};q=deque([a])
  while q:
   v=q.popleft()
   for u in G[v]:
    if u not in dist:dist[u]=dist[v]+1;q.append(u)
  out[a]=dist
 return out

def directly_total_visible(X,G,D):
 # No distance-2 criterion is used. For every source, BFS can arrive at X
 # vertices but cannot continue from them, except from the source itself.
 for a in G:
  dist={a:0};q=deque([a])
  while q:
   v=q.popleft()
   if v!=a and v in X:continue
   for u in G[v]:
    if u not in dist:dist[u]=dist[v]+1;q.append(u)
  if dist!=D[a]:return False
 return True

def components(G):
 seen=set();out=[]
 for a in G:
  if a in seen:continue
  c={a};q=[a];seen.add(a)
  while q:
   v=q.pop()
   for u in G[v]-seen:seen.add(u);c.add(u);q.append(u)
  out.append(c)
 return out

def exact_independent(G):
 # Full branch recurrence, not MILP. Cache and split connected components.
 W=list(G); idx={v:i for i,v in enumerate(W)}
 N=[sum(1<<idx[u] for u in G[v]) for v in W]
 @lru_cache(None)
 def solve(mask):
  if not mask:return 0
  v=max((i for i in range(len(W)) if mask>>i&1),key=lambda i:(N[i]&mask).bit_count())
  if not N[v]&mask:return mask.bit_count()
  return max(solve(mask&~(1<<v)),1+solve(mask&~((1<<v)|N[v])))
 return solve((1<<len(W))-1)

def audit(n,exhaustive=False):
 W=words(n);G=adjacency(W);D=distances(G)
 A={a for a in W if eligible(a)}
 assert A=={a for a in W if directly_total_visible({a},G,D)}
 H={a:{b for b in A if conflict(a,b)} for a in A}
 for a,b in combinations(A,2):
  assert (not directly_total_visible({a,b},G,D))==conflict(a,b),(n,a,b)
 Cs=components(H);alpha=sum(exact_independent({a:H[a]&c for a in c}) for c in Cs)
 tested=0
 if exhaustive:
  A=list(A)
  for mask in range(1<<len(A)):
   X={a for i,a in enumerate(A) if mask>>i&1}
   candidate=all(not(H[a]&X) for a in X)
   assert candidate==directly_total_visible(X,G,D),(n,X)
   tested+=1
 return n,len(W),len(A),sum(map(len,H.values()))//2,alpha,tested

if __name__=='__main__':
 import sys
 max_n=int(sys.argv[1]) if len(sys.argv)>1 else 7
 for n in range(1,max_n+1):print(audit(n,exhaustive=n<=7),flush=True)
