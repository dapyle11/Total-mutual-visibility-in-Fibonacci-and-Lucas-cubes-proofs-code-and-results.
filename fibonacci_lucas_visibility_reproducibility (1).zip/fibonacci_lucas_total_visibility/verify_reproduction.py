#!/usr/bin/env python3
"""Run the supplement and compare fresh outputs against the distributed data.

Never overwrites distributed reference records. All output goes to a separate
user-selected directory. Full mode reproduces the recorded finite ranges;
quick mode is a smoke test, not a replacement for full verification.
"""
from pathlib import Path
import argparse
import ast
import json
import math
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def read_jsonl(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]


def strip_timing(value):
    if isinstance(value, dict):
        return {k: strip_timing(v) for k, v in value.items() if k != 'seconds'}
    if isinstance(value, list):
        return [strip_timing(v) for v in value]
    return value


def same(a, b):
    if isinstance(a, dict) and isinstance(b, dict):
        return a.keys() == b.keys() and all(same(a[k], b[k]) for k in a)
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(same(x, y) for x, y in zip(a, b))
    if isinstance(a, float) or isinstance(b, float):
        return math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12)
    return a == b


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--full', action='store_true', help='reproduce every recorded finite range')
    parser.add_argument('--output-dir', type=Path, default=Path('test_outputs'))
    parser.add_argument('--timeout', type=float, default=600.0, help='seconds allowed per subprocess')
    args = parser.parse_args()
    if sys.version_info < (3, 10):
        parser.error('Python 3.10 or later is required (int.bit_count).')
    if not __debug__ or os.environ.get('PYTHONOPTIMIZE'):
        parser.error('Assertions must be enabled; do not use -O, -OO, or PYTHONOPTIMIZE.')
    output = args.output_dir.resolve()
    if output == ROOT:
        parser.error('Choose a separate output directory; reference data must not be overwritten.')
    output.mkdir(parents=True, exist_ok=True)
    report = {'mode': 'full' if args.full else 'quick', 'python': sys.version.split()[0], 'checks': []}

    def run(label, script, arguments, filename):
        command = [sys.executable, '-B', str(ROOT / script), *arguments]
        start = time.monotonic()
        target = output / filename
        with target.open('w', encoding='utf-8') as out, (output / (filename + '.stderr.txt')).open('w', encoding='utf-8') as err:
            subprocess.run(command, cwd=ROOT, stdout=out, stderr=err, check=True,
                           timeout=args.timeout, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        report['checks'].append({'check': label, 'seconds': round(time.monotonic() - start, 4), 'passed': True})
        print('PASS execution:', label, flush=True)
        return target

    n = 20 if args.full else 10
    exact = read_jsonl(run('direct eligible-word conflict graphs', 'exact_total_visibility.py', [str(n)], 'exact_results.jsonl'))
    reference_exact = read_jsonl(ROOT / 'exact_results.jsonl')[:n]
    assert strip_timing(exact) == strip_timing(reference_exact)
    summary = [{k: v for k, v in row.items() if k != 'witness'} for row in exact]
    assert strip_timing(summary) == strip_timing(read_json(ROOT / 'exact_summary.json')[:n])
    (output / 'exact_summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')

    audit_reference = read_json(ROOT / 'independent_audit_validation.json')
    definition_n = 7 if args.full else 6
    definition_path = run('global-definition BFS on all eligible subsets', 'independent_definition_audit.py', [str(definition_n)], 'definition_audit.txt')
    observed = [ast.literal_eval(line) for line in definition_path.read_text().splitlines()]
    fields = ('n', 'vertices', 'eligible', 'conflict_edges', 'exact_total_visibility', 'eligible_subsets_checked')
    assert observed == [tuple(row[k] for k in fields) for row in audit_reference['definition_checks'][:definition_n]]

    component_n = 17 if args.full else 10
    component_path = run('independent eligible-component audit', 'independent_component_audit.py', [str(component_n)], 'component_audit.txt')
    component_rows = []
    for line in component_path.read_text().splitlines():
        dimension, eligible, count, inventory = line.split(maxsplit=3)
        component_rows.append((int(dimension), int(eligible), int(count), ast.literal_eval(inventory)))
    reference = audit_reference['component_checks']
    assert [(row[0], row[2]) for row in component_rows] == list(zip(reference['dimensions_checked'], reference['component_counts']))[:component_n - 1]

    max_inventory_n = 60 if args.full else 20
    direct_n = 18 if args.full else 10
    inventory_path = run('component inventory', 'component_inventory.py', ['--max-n', str(max_inventory_n), '--direct-through', str(direct_n)], 'component_inventory_validation.json')
    assert read_json(inventory_path) == read_json(ROOT / 'component_inventory_validation.json')[:max_inventory_n + 1]

    component_exact_path = run('component-type optimization using the shared MIS kernel', 'component_exact.py', ['--max-n', str(n)], 'component_exact_validation.json')
    calculated = strip_timing(read_json(component_exact_path))
    expected = strip_timing(read_json(ROOT / 'component_exact_validation.json'))
    assert calculated['values'] == expected['values'][:n + 1]
    expected_types = {tuple(row['type']): row for row in expected['types']}
    assert all(row == expected_types[tuple(row['type'])] for row in calculated['types'])
    assert calculated['matches_direct_eligible_graph_through'] == n
    if args.full:
        assert calculated == expected

    generating_path = run('exact generating-function identities and coefficient histograms', 'generating_function_checks.py', ['--max-n', str(max_inventory_n)], 'component_generating_function_validation.json')
    calculated = read_json(generating_path)
    expected = read_json(ROOT / 'component_generating_function_validation.json')
    assert calculated['weighted_dimension_histograms'] == expected['weighted_dimension_histograms'][:max_inventory_n + 1]
    if args.full:
        assert calculated == expected

    mode = 'all' if args.full else 'cubes'
    structural_path = run('structural endpoint checks (' + mode + ')', 'structural_endpoint_checks.py', [mode], 'structural_endpoint_validation.jsonl')
    expected = read_jsonl(ROOT / 'structural_endpoint_validation.jsonl')
    if not args.full:
        expected = [row for row in expected if row['kind'] == 'cube_fibre']
    assert same(read_jsonl(structural_path), expected)

    report['reference_comparisons_passed'] = True
    report['formal_proof_certificate'] = False
    report['global_definition_all_eligible_subsets_through'] = definition_n
    report['global_definition_lucas_all_eligible_subsets_through'] = 7 if args.full else None
    (output / 'verification_report.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print('PASS: all requested executions and reference comparisons. No formal proof certificate.', flush=True)


if __name__ == '__main__':
    main()
