#!/usr/bin/env python3
"""Exact total mutual visibility in Fibonacci cubes.

Uses Python integer branch-and-bound with memoized exact recurrences; no MILP.
The conflict graph characterization is separately compared with direct
common-neighbor constraints through dimension 12. Optimization on the constructed
conflict graphs is exhaustive, not a heuristic. This is not an all-subsets
BFS verification of the global definition. A selected set is retained for
feasibility checks.
"""
from itertools import combinations
from functools import lru_cache
import json, sys, time

def eligible_words(n):
    return [v for v in range(1<<n) if '11' not in (w:=format(v,f'0{n}b')) and '0000' not in '0'+w+'0'] if n else [0]

def conflict_graph(n):
    words=eligible_words(n); loc={v:i for i,v in enumerate(words)}
    adj=[0]*len(words)
    pairs=[(1<<i)|(1<<j) for i in range(n) for j in range(i+2,n)]
    for a,v in enumerate(words):
        for p in pairs:
            b=loc.get(v^p)
            if b is not None: adj[a]|=1<<b
    return words,adj

def components(mask, adj):
    result=[]
    while mask:
        reached=0; todo=mask&-mask
        while todo:
            reached|=todo; nxt=0
            while todo:
                bit=todo&-todo; todo^=bit
                nxt|=adj[bit.bit_length()-1]
            todo=nxt&mask&~reached
        result.append(reached); mask&=~reached
    return result

def alpha_exact(adj):
    calls=0
    @lru_cache(None)
    def solve(mask):
        nonlocal calls
        calls+=1
        if not mask:return 0
        # Every isolated vertex belongs to a maximum independent set.
        isolated=0; remain=mask
        while remain:
            bit=remain&-remain; remain^=bit
            if not(adj[bit.bit_length()-1]&mask):isolated|=bit
        if isolated:return isolated|solve(mask^isolated)
        comps=components(mask,adj)
        if len(comps)>1:
            answer=0
            for c in comps:answer|=solve(c)
            return answer
        # Exhaustive deletion/contraction recurrence.
        ids=[];remain=mask
        while remain:
            bit=remain&-remain;remain^=bit;ids.append(bit.bit_length()-1)
        v=max(ids,key=lambda v:(adj[v]&mask).bit_count());bit=1<<v
        exclude=solve(mask^bit)
        include=bit|solve(mask&~(adj[v]|bit))
        return include if include.bit_count()>=exclude.bit_count() else exclude
    answer=solve((1<<len(adj))-1)
    return answer,calls,solve.cache_info().currsize

def verify_local(n, words,adj):
    V=[v for v in range(1<<n) if not(v&(v>>1))];S=set(V)
    neighbors={v:{v^(1<<i) for i in range(n)}&S for v in V}
    forced=set();pairs=set()
    for a in V:
        for i,j in combinations(range(n),2):
            b=a^(1<<i)^(1<<j)
            if b<=a or b not in S:continue
            common=neighbors[a]&neighbors[b]
            assert 1<=len(common)<=2
            if len(common)==1:forced.update(common)
            else:pairs.add(tuple(sorted(common)))
    assert set(words)==S-forced,(n,'eligibility differs')
    expected={p for p in pairs if not(set(p)&forced)}
    actual={(words[a],words[b]) for a in range(len(words)) for b in range(a+1,len(words)) if adj[a]>>b&1}
    assert actual==expected,(n,'conflict edge differs')

def main():
    maxn=int(sys.argv[1]) if len(sys.argv)>1 else 20
    for n in range(1,maxn+1):
        t=time.monotonic();words,adj=conflict_graph(n)
        if n<=12:verify_local(n,words,adj)
        comp=components((1<<len(words))-1,adj)
        # Relabel components so memoized states use small integers.
        witness=[];calls=0
        for mask in comp:
            ids=[i for i in range(len(words)) if mask>>i&1];loc={v:i for i,v in enumerate(ids)}
            small=[sum(1<<loc[j] for j in ids if adj[i]>>j&1) for i in ids]
            chosen,c,_=alpha_exact(small);calls+=c
            witness.extend(words[ids[k]] for k in range(len(ids)) if chosen>>k&1)
        assert all((a^b).bit_count()!=2 or ((a^b)&((a^b)>>1)) for a,b in combinations(witness,2))
        result={'dimension':n,'graph_order':sum(not(v&(v>>1)) for v in range(1<<n)),
                'eligible':len(words),'conflict_edges':sum(a.bit_count() for a in adj)//2,
                'components':len(comp),'max_component':max(m.bit_count() for m in comp),
                'mu_total':len(witness),'recursion_states':calls,'seconds':round(time.monotonic()-t,4),
                'witness':[format(v,f'0{n}b') for v in sorted(witness)]}
        print(json.dumps(result),flush=True)
if __name__=='__main__':main()
