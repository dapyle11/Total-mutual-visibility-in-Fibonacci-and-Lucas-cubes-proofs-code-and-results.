"""Exact type generating function for eligible Fibonacci-cube components.

No third-party dependencies. The coefficient at z^n is a Counter from sorted
positive Fibonacci factor orders to component multiplicity. Excluding Γ_0
factors is canonical. See the accompanying manuscript for the derivation.
"""
from collections import Counter
from functools import lru_cache
import json


def plus(a, b):
    c = a.copy(); c.update(b); return +c


def times(a, b):
    c = Counter()
    for x, u in a.items():
        for y, v in b.items():
            c[tuple(sorted(x+y))] += u*v
    return c


def monomial(r):
    return Counter({(r,) if r else (): 1})


def inventories(N):
    # I=1+z²Y(z²), L=z+(1+z³)Y(z²), Y(q)=sum y_r q^r,
    # y_0=1, R=1/(1-z³I). Work in the polynomial ring in y_r.
    I = [Counter() for _ in range(N+1)]
    L = [Counter() for _ in range(N+1)]
    R = [Counter() for _ in range(N+1)]
    F = [Counter() for _ in range(N+1)]
    I[0] = monomial(0)
    if N>=1: L[1].update(monomial(0))
    for r in range(N//2+1):
        if 2*r+2<=N: I[2*r+2].update(monomial(r))
        L[2*r].update(monomial(r))
        if 2*r+3<=N: L[2*r+3].update(monomial(r))
    R[0] = monomial(0)
    for n in range(3,N+1):
        for j in range(n-2):
            R[n].update(times(I[j], R[n-3-j]))
    F[0] = monomial(0)
    for r in range(1,(N+1)//2+1):
        F[2*r-1].update(monomial(r))
    for r in range(N//2):
        F[2*r+2].update({k: 2*v for k,v in monomial(r).items()})
    for n in range(3,N+1): F[n].update(I[n-3])
    # z^4 L^2 R counts maximal sets with at least one length-3 gap.
    LL = [Counter() for _ in range(N+1)]
    for n in range(N+1):
        for j in range(n+1): LL[n].update(times(L[j],L[n-j]))
    for n in range(4,N+1):
        for j in range(n-3): F[n].update(times(LL[j],R[n-4-j]))
    return F


def fibsize(r):
    a,b=1,2
    for _ in range(r): a,b=b,a+b
    return a


def order(rs):
    p=1
    for r in rs:p*=fibsize(r)
    return p


def maximal_set_inventory(n):
    # Independent direct enumeration of maximal independent sets of P_n.
    # R contains exactly deletable singleton-eligible elements of M.
    C=Counter()
    for M in range(1<<n):
        if M & (M<<1):continue
        if ((M|(M<<1)|(M>>1)) & ((1<<n)-1)) != (1<<n)-1:continue
        R=M
        for j in range(n):
            if M>>j&1:continue
            N=M & (((1<<(j-1)) if j else 0) | ((1<<(j+1)) if j+1<n else 0))
            if N.bit_count()==1:R &= ~N
        runs=[]
        while R:
            bit=R & -R; i=bit.bit_length()-1; r=0
            while i<n and R>>i&1:
                R &= ~(1<<i);r+=1;i+=2
            runs.append(r)
        C[tuple(sorted(runs))]+=1
    return C


def validate(N=40,direct=16):
    F=inventories(N)
    b=[1,2,2,4]
    for n in range(4,N+1):b.append(b[-2]+b[-3]+b[-4])
    c=[1,1,2]
    for n in range(3,N+1):c.append(c[-2]+c[-3])
    rows=[]
    for n,C in enumerate(F):
        assert sum(C.values())==c[n],(n,C,c[n])
        assert sum(v*order(rs) for rs,v in C.items())==b[n],(n,C,b[n])
        if n<=direct:assert C==maximal_set_inventory(n),(n,C,maximal_set_inventory(n))
        lower=sum(v*((order(rs)+(1<<(max(1,sum(rs))-1).bit_length())-1)//(1<<(max(1,sum(rs))-1).bit_length())) for rs,v in C.items())
        rows.append(dict(n=n,eligible=b[n],components=c[n],types=len(C),
                         largest_component=max(order(rs) for rs in C),
                         dimension_sum=sum(v*order(rs)*sum(rs) for rs,v in C.items()),
                         component_syndrome_lower_bound=lower))
    return rows

if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--max-n',type=int,default=40)
    p.add_argument('--direct-through',type=int,default=16);args=p.parse_args()
    print(json.dumps(validate(args.max_n,args.direct_through),indent=2))
